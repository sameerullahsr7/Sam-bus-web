import axios from "axios"
import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"
import { baseUrl } from "../../core"
import CircularProgress from '@mui/material/CircularProgress';
import DropAccordion from "./DropAccordion";
import moment from "moment";
import busEmoji from "../../assets/images/bus-emoji.svg"
import { MdDone } from "react-icons/md";

const Step1 = ({ step, setStep, data, _data, set_data }: any) => {

    const navigate = useNavigate()

    console.log(step, setStep, data)
    const [buses, setBuses] = useState([])
    const [routes, setRoutes] = useState<null | any[]>(null)

    useEffect(() => {
        getRoutes()
        getBuses()
    }, [])

    const getRoutes = async () => {

        if (!data?.from || !data?.to || !data?.passengers || !data?.date) navigate("/")

        try {

            const routeResp = await axios.post(`${baseUrl}/api/v1/bus-routes`, {
                passengers: data?.passengers,
                date: data?.date,
                destination: data?.to,
                origin: data?.from
            }, { withCredentials: true })

            setRoutes(routeResp?.data?.data)

        } catch (error: any) {
            console.log(error)
        }

    }

    const getBuses = async () => {
        try {

            const busesResp = await axios.get(`${baseUrl}/api/v1/buses`, {
                withCredentials: true
            })

            setBuses(busesResp?.data?.data)

        } catch (error) {
            console.log(error)
        }
    }

    return (
        <div className="w-full bg-[#0a101d] flex flex-col gap-4 p-8 pt-16">
            <h1 className="w-full text-left text-[#fff] font-bold text-[40px]">
                {`1. Select your Bus from ${data?.from} to ${data?.to}`}
            </h1>
            <h1 className="w-full text-left text-[#fff] font-bold text-[32px] bg-[#29ABE2] p-4">
                All Bus include a generous 10 KG Hand Baggage
            </h1>
            <div className="w-full flex justify-between items-center gap-4 p-4 mt-4">
                <p className="text-[#29ABE2] text-[48px]" >{`<`}</p>
                <div className="w-full h-[30px] flex justify-start items-center gap-4 overflow-auto no-scrollbar">
                    {
                        buses?.length ? buses?.map((bus: any) => (
                            <>
                                <div className="w-fit p-2 text-[#fff] text-[32px] font-bold flex justify-center items-center text-center">{`${bus?.name}>`}</div>
                            </>
                        )) : null
                    }
                </div>
                <p className="text-[#29ABE2] text-[48px]" >{`>`}</p>
            </div>
            <div className="w-full mt-4 border-b-2 border-[#F2F2F2]"></div>
            <div className="flex flex-col gap-4 p-4">
                {
                    !routes ?
                        <div className="w-full flex justify-center items-center p-4 mt-4">
                            <CircularProgress
                                color="primary"
                            />
                        </div>
                        : routes?.length ? routes?.map((route: any) => (
                            <>
                                <DropAccordion
                                    button={`PKR ${route?.price?.toLocaleString()}`}
                                    label={<>
                                        <div className="w-full flex flex-col items-center gap-4">
                                            <div className="w-full flex items-center gap-2">
                                                <p className="text-[#fff] font-bold text-[32px]">{moment(route?.arrivalTime).format('LT')}</p>
                                                <img src={busEmoji} alt="bus"
                                                    className="w-[70px] h-[70px] object-contain"
                                                />
                                                <div className="flex-1 border-b-2 border-[#F2F2F2]"></div>
                                                <p className="text-[#fff] font-bold text-[32px]">{moment(route?.departureTime).format('LT')}</p>
                                            </div>
                                            <div className="w-full flex justify-around items-center">
                                                <p className="text-[#fff]">{route?.origin}/{route?.destination}</p>
                                                <p className="text-[#fff]">
                                                    {
                                                        `${moment(route?.arrivalTime)?.diff(route?.departureTime, 'minutes') / 60} hour(s) ${moment(route?.arrivalTime)?.diff(route?.departureTime, 'minutes') % 60 >= 1 ? `${moment(route?.arrivalTime)?.diff(route?.departureTime, 'minutes') % 60} minute(s)` : ""}`
                                                    }
                                                </p>
                                            </div>
                                        </div>
                                    </>}
                                    content={<>
                                        <div className="w-full flex flex-col">
                                            <div className="p-2 px-4 bg-[#29ABE2] text-[#fff] text-left text-[32px] font-bold">Basic</div>
                                            <div className="p-4 py-2 bg-[#fff] text-[#000] flex items-center gap-4 text-left text-[24px] font-bold">
                                                <MdDone
                                                    style={{
                                                        background: "#000",
                                                        padding: 4,
                                                        borderRadius: 100,
                                                    }}
                                                /> Lorem ipsum
                                            </div>
                                            <div className="p-4 py-2 bg-[#fff] text-[#000] flex items-center gap-4 text-left text-[24px] font-bold">
                                                <MdDone
                                                    style={{
                                                        background: "#000",
                                                        padding: 4,
                                                        borderRadius: 100,
                                                    }}
                                                /> Lorem ipsum
                                            </div>
                                            <div className="p-4 py-2 bg-[#fff] text-[#000] flex items-center gap-4 text-left text-[24px] font-bold">
                                                <MdDone
                                                    style={{
                                                        background: "#000",
                                                        padding: 4,
                                                        borderRadius: 100,
                                                    }}
                                                /> Lorem ipsum
                                            </div>
                                            <div className="p-4 py-2 bg-[#fff] text-[#000] flex items-center gap-4 text-left text-[24px] font-bold">
                                                <MdDone
                                                    style={{
                                                        background: "#000",
                                                        padding: 4,
                                                        borderRadius: 100,
                                                    }}
                                                /> Lorem ipsum
                                            </div>
                                            <div className="p-4 py-2 bg-[#fff] text-[#000] flex items-center gap-4 text-left text-[24px] font-bold">
                                                <MdDone
                                                    style={{
                                                        background: "#000",
                                                        padding: 4,
                                                        borderRadius: 100,
                                                    }}
                                                /> Lorem ipsum
                                            </div>
                                            <div className="p-4 px-8 py-2 bg-[#fff] text-[#000] flex justify-between items-center gap-4 border-t-2 border-t-[#000]">
                                                <p className="font-bold w-fit text-[#000] text-[32px]">PKR {route?.price?.toLocaleString()}</p>
                                                <p className="font-bold w-fit text-[#000] text-[18px] cursor-pointer"
                                                    onClick={() => {
                                                        set_data({ ..._data, bus: route })
                                                        setStep(3)
                                                    }}
                                                >Select</p>
                                            </div>
                                        </div>
                                    </>}
                                />
                            </>
                        )) : <h1 className="w-full text-center text-[#fff] font-bold text-[32px] mt-8">Oops!... No buses available.</h1>
                }
            </div>
        </div>
    )
}

export default Step1