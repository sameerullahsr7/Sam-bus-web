import axios from "axios";
import { useEffect, useState } from "react";
import { baseUrl } from "../../core";
import { Button, CircularProgress } from "@mui/material";
import { useNavigate } from "react-router-dom";

const Step2 = ({ step, setStep, data, _data, set_data }: any) => {

    console.log(step, setStep, data, _data, set_data);

    const [seats, setSeats] = useState<number[] | null>(null);
    const [selectedSeats, setSelectedSeats] = useState<number[]>([]);
    const navigate = useNavigate()

    useEffect(() => {
        getSeats();
    }, []);

    const getSeats = async () => {
        try {
            const resp = await axios.get(`${baseUrl}/api/v1/seats/${_data?.bus?._id}`, {
                withCredentials: true
            });

            setSeats(resp?.data?.availableSeats);
        } catch (error) {
            console.log(error);
        }
    };

    const handleSelect = (seatNumber: number) => {
        if (selectedSeats.includes(seatNumber)) {
            setSelectedSeats(selectedSeats.filter(seat => seat !== seatNumber));
        } else {
            setSelectedSeats([...selectedSeats, seatNumber]);
        }
    };

    return (
        <div className="w-full bg-[#0a101d] flex flex-col gap-4 p-8 pt-16">
            <h1 className="w-full text-center font-bold text-[64px] text-[#fff]">Select the seat</h1>
            <div className="w-full border-b-2 border-b-[#fff]"></div>
            <div className="w-full flex justify-evenly items-center mt-8">
                <div className="flex flex-col items-center gap-4">
                    <div className="w-[83px] h-[83px] bg-[#D61717]"></div>
                    <p className="w-full text-center text-[#fff]">Booked Seats</p>
                </div>
                <div className="flex flex-col items-center gap-4">
                    <div className="w-[83px] h-[83px] bg-[#4DD836]"></div>
                    <p className="w-full text-center text-[#fff]">Selected Seats</p>
                </div>
                <div className="flex flex-col items-center gap-4">
                    <div className="w-[83px] h-[83px] bg-[#29ABE2]"></div>
                    <p className="w-full text-center text-[#fff]">Empty Seats</p>
                </div>
            </div>
            <p className="w-full text-left text-[#fff] text-xl">Entry</p>
            <div className="w-[600px] grid grid-cols-6 gap-12 mx-auto">
                {
                    seats ? seats?.map((seat: number) => (
                        <div
                            className={`w-[80px] h-[80px] text-[#fff] font-bold text-center cursor-pointer flex justify-center items-center ${selectedSeats.includes(seat) ? 'bg-[#4DD836]' : 'bg-[#29ABE2]'}`}
                            key={seat}
                            onClick={() => handleSelect(seat)}
                        >
                            {seat}
                        </div>
                    )) : (
                        <div className="w-full flex justify-center items-center p-4 mt-4">
                            <CircularProgress color="primary" />
                        </div>
                    )
                }
            </div>
            <Button
                sx={{
                    width: "16em",
                    borderRadius: 4,
                    marginX: "auto",
                    marginTop: 16
                }}
                variant="contained"
                color="secondary"
                onClick={() => navigate("/")}
            >Confirm Selection</Button>
        </div>
    );
};

export default Step2;