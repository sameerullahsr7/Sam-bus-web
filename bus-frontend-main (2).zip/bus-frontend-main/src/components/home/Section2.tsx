import section2a from "../../assets/images/section-2a.svg"
import section2b from "../../assets/images/section-2b.svg"

const Section2 = () => {
    return (
        <div className='w-full p-8 py-8 flex flex-col bg-[#0f172a]'>
            <img src={section2b} alt="section-2a"
            className="w-full h-full object-contain"
            />
            <img src={section2a} alt="section-2b"
            className="w-full h-full object-contain"
            />
        </div>
    )
}

export default Section2