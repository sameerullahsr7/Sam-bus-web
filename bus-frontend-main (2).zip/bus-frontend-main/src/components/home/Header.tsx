import "../../tailwind.css"
import "./main.css"
import { TfiHeadphoneAlt } from "react-icons/tfi";
import { IoSunnySharp } from "react-icons/io5";
import { IoMdPerson } from "react-icons/io";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";

const Header = ({ onAboutClick, onReviewsClick, onFAQsClick }: any) => {

    const navigate = useNavigate()
    const currentUser = useSelector((state: any) => state?.user)

    return (
        <div className="w-full h-fit py-8 px-12 flex justify-between items-center bg-[#070B15] sticky top-0 z-20">
            <div className="w-fit flex justify-start items-center gap-4">
                <p className="text-[#fff] uppercase cursor-pointer" onClick={onAboutClick}>About</p>
                <p className="text-[#fff] uppercase cursor-pointer" onClick={onReviewsClick}>Reviews</p>
                <p className="text-[#fff] uppercase cursor-pointer" onClick={onFAQsClick}>FAQs</p>
            </div>
            <div className="w-fit text-[#fff] flex justify-start items-center gap-4">
                <TfiHeadphoneAlt
                    className="cursor-pointer"
                />
                <IoSunnySharp
                    className="cursor-pointer"
                />
                {
                    currentUser?.isLogin == false && <>
                        <div className="flex items-center gap-2 cursor-pointer"
                            onClick={() => navigate("/auth")}
                        >
                            <IoMdPerson
                                className="cursor-pointer"
                            />
                            <p className="text-[#fff] uppercase cursor-pointer">Login</p>
                        </div>
                        <div className="flex items-center gap-2 cursor-pointer"
                            onClick={() => navigate("/auth")}
                        >
                            <IoMdPerson
                                className="cursor-pointer"
                            />
                            <p className="text-[#fff] uppercase cursor-pointer">Register</p>
                        </div>
                    </>
                }
            </div>
        </div>
    )
}

export default Header