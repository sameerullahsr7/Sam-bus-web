import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';

export default function AccordionMui({ title, description }: any) {
  return (
    <>
      <Accordion sx={{
        background: "#1E293B"
      }}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1-content"
          id="panel1-header"
        >
          <p className='w-full text-[#fff] p-2'>
            {title}
          </p>
        </AccordionSummary>
        <AccordionDetails
          sx={{
            color: "#fff"
          }}
        >
          <p className='w-full text-[#fff] p-2'>
            {description}
          </p>
        </AccordionDetails>
      </Accordion>
    </>
  );
}
