import AccordionMui from "./AccordionMui"
import "./main.css"

import UserCard from "./UserCard"

const Section3 = () => {

    const reviews: any = [
        {
            name: "Farhan M.",
            star: 5,
            time: new Date(),
            image: "https://avatars.githubusercontent.com/u/120649081?v=4",
            message: "En ipsom gestionamos de forma integral ayudas de sostenibilidad, eficiencia energética, inversiones industriales e innovación para empresas"
        },
        {
            name: "Farhan M.",
            star: 5,
            time: new Date(),
            image: "",
            message: "En ipsom gestionamos de forma integral ayudas de sostenibilidad, eficiencia energética, inversiones industriales e innovación para empresas"
        },
        {
            name: "Farhan M.",
            star: 5,
            time: new Date(),
            image: "https://avatars.githubusercontent.com/u/120649081?v=4",
            message: "En ipsom gestionamos de forma integral ayudas de sostenibilidad, eficiencia energética, inversiones industriales e innovación para empresas"
        },
        {
            name: "Farhan M.",
            star: 5,
            time: new Date(),
            image: "",
            message: "En ipsom gestionamos de forma integral ayudas de sostenibilidad, eficiencia energética, inversiones industriales e innovación para empresas"
        },
        {
            name: "Farhan M.",
            star: 5,
            time: new Date(),
            image: "https://avatars.githubusercontent.com/u/120649081?v=4",
            message: "En ipsom gestionamos de forma integral ayudas de sostenibilidad, eficiencia energética, inversiones industriales e innovación para empresas"
        },
        {
            name: "Farhan M.",
            star: 5,
            time: new Date(),
            image: "https://avatars.githubusercontent.com/u/120649081?v=4",
            message: "En ipsom gestionamos de forma integral ayudas de sostenibilidad, eficiencia energética, inversiones industriales e innovación para empresas"
        },
        {
            name: "Farhan M.",
            star: 5,
            time: new Date(),
            image: "",
            message: "En ipsom gestionamos de forma integral ayudas de sostenibilidad, eficiencia energética, inversiones industriales e innovación para empresas"
        },
        {
            name: "Farhan M.",
            star: 5,
            time: new Date(),
            image: "https://avatars.githubusercontent.com/u/120649081?v=4",
            message: "En ipsom gestionamos de forma integral ayudas de sostenibilidad, eficiencia energética, inversiones industriales e innovación para empresas"
        },
        {
            name: "Farhan M.",
            star: 5,
            time: new Date(),
            image: "",
            message: "En ipsom gestionamos de forma integral ayudas de sostenibilidad, eficiencia energética, inversiones industriales e innovación para empresas"
        },
        {
            name: "Farhan M.",
            star: 5,
            time: new Date(),
            image: "",
            message: "En ipsom gestionamos de forma integral ayudas de sostenibilidad, eficiencia energética, inversiones industriales e innovación para empresas"
        },
        {
            name: "Farhan M.",
            star: 5,
            time: new Date(),
            image: "https://avatars.githubusercontent.com/u/120649081?v=4",
            message: "En ipsom gestionamos de forma integral ayudas de sostenibilidad, eficiencia energética, inversiones industriales e innovación para empresas"
        },
    ]

    return (
        <div className='w-full p-8 flex flex-col bg-[#0f172a]'>
            <h1 className="uppercase text-[40px] w-full text-center text-[#fff] font-bold">WHAT OUR CLIENT SAYS</h1>
            <div className="scroll-container w-full flex flex-row-reverse items-center mt-16">
                {
                    (reviews && reviews?.length) ? reviews?.map((review: any) => (
                        <UserCard
                            name={review?.name}
                            star={review?.star}
                            time={review?.time}
                            message={review?.message}
                            image={review?.image}
                        />
                    )) : null
                }
            </div>
            <h1 className="uppercase mt-24 text-[40px] w-full text-center text-[#fff] font-bold">FREQUENTLY ASKED QUESTION</h1>
            <div className="w-full flex flex-col gap-4 mt-16">
                <AccordionMui
                    title="How do I book tickets?"
                    description="En ipsom gestionamos de forma integral ayudas de sostenibilidad, eficiencia energética, inversiones industriales e innovación para empresas"
                />
                <AccordionMui
                    title="How do I book tickets?"
                    description="En ipsom gestionamos de forma integral ayudas de sostenibilidad, eficiencia energética, inversiones industriales e innovación para empresas"
                />
                <AccordionMui
                    title="How do I book tickets?"
                    description="En ipsom gestionamos de forma integral ayudas de sostenibilidad, eficiencia energética, inversiones industriales e innovación para empresas"
                />
                <AccordionMui
                    title="How do I book tickets?"
                    description="En ipsom gestionamos de forma integral ayudas de sostenibilidad, eficiencia energética, inversiones industriales e innovación para empresas"
                />
            </div>
            <div className="p-[2em]"></div>
        </div>
    )
}

export default Section3