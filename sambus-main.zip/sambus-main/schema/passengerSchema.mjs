import mongoose from 'mongoose';

const passengerSchema = new mongoose.Schema({
  fullName: {
    type: String,
    required: true
  },
  age: {
    type: Number,
    required: true
  },
  CNIC: {
    type: String,
    validate: {
      validator: function(v) {
        // Validate CNIC here
        // Example: Check if the CNIC format is valid
        return /\d{5}-\d{7}-\d/.test(v);
      },
      message: props => `${props.value} is not a valid CNIC number!`
    }
  },
  seatNumber: {
    type: Number,
    required: true,
    required: true
  },
  route: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Route',
    required: true
  },
  bookedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  isPaid: {
    type: Boolean,
    default: false
  }
});

export const passengerModel = mongoose.model('Passenger', passengerSchema);