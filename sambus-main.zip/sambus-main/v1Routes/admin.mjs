import express from 'express';
import { errorCodes } from '../core.mjs';
import { userModel } from '../schema/userSchema.mjs';
import { busModel } from '../schema/busSchema.mjs';
import { routeModel } from '../schema/routeSchema.mjs';
import { isValidObjectId } from 'mongoose';
const router = express.Router();

router.post('/bus', async (req, res, next) => {
    try {
        const { registrationNumber, name, totalSeats } = req?.body;
        const userId = req.user._id;
        if (!registrationNumber
            || !name
            || !totalSeats
            || !userId
        ){
            res.status(403).send({
                message: "REQUIRED_PARAMETER_MISSING",
                errorCode: errorCodes.REQUIRED_PARAMETER_MISSING,
            })
            return;
        }
        const user = await userModel.findOne({ _id: req.user._id, isAdmin: true });
        if (!user) {
            res.status(401).send({
                message: "UNAUTHORIZED",
                errorCode: errorCodes.UNAUTHORIZED,
            })
            return;
        }
        const foundBus = await busModel.findOne({ busNumber: registrationNumber }).lean();

        if (foundBus) {
            res.status(403).send({
                message: "BUS_ALREADY_EXISTS with this name or busNumber",
                errorCode: errorCodes.BUS_ALREADY_EXIST,
            })
            return;
        }

        await busModel.create({
            busNumber: registrationNumber,
            name: name,
            totalSeats: totalSeats,
        });

        res.send({
            message: 'Bus created Successfully',
            errorCode: errorCodes.SUCCESS,
        });
    } catch (error) {
        console.error(error.message);
        res.status(500).send({
            message: `UNKNOWN_SERVER_ERROR: ${error.message}`,
            errorCode: errorCodes.UNKNOWN_SERVER_ERROR
        })
    }
})

router.post('/bus-route/:busId', async (req, res, next) => {
    try {
        const busId = req?.params?.busId;
        const { origin, destination, arrivalTime, departureTime, date } = req?.body;
        const userId = req.user._id;

        const user = await userModel.findOne({ _id: userId, isAdmin: true });
        if (!user) {
            res.status(401).send({
                message: "UNAUTHORIZED",
                errorCode: errorCodes.UNAUTHORIZED,
            })
            return;
        }
        
        // Check if all required parameters are provided
        if (!busId || !origin || !destination || !arrivalTime || !departureTime || !date) {
            res.status(403).send({
                message: "REQUIRED_PARAMETER_MISSING",
                errorCode: errorCodes.REQUIRED_PARAMETER_MISSING,
            });
            return;
        }
        
        // Check if busId is a valid ObjectId
        if (!isValidObjectId(busId)) {
            res.status(403).send({
                errorCode: errorCodes.INVALID_BUS_ID,
                message: 'INVALID_BUS_ID',
            });
            return;
        }
        
        // Find the bus with the provided busId
        const bus = await busModel.findById(busId);
        
        // If bus does not exist, return an error
        if (!bus) {
            res.status(400).send({
                message: "BUS_NOT_EXIST",
                errorCode: errorCodes.BUS_NOT_EXIST,
            });
            return;
        }

        // Convert time strings to Date objects
        const departureDateTime = new Date(date + 'T' + departureTime + ':00');
        const arrivalDateTime = new Date(date + 'T' + arrivalTime + ':00');

        // Create a new route with the provided details
        await routeModel.create({
            origin: origin,
            destination: destination,
            departureTime: departureDateTime,
            arrivalTime: arrivalDateTime,
            totalSeats: bus.totalSeats,
            availableSeats: bus.totalSeats,
            bus: bus._id,
            date: date
        });

        // Send success response
        res.status(200).send({
            message: 'Bus Route created Successfully',
            errorCode: errorCodes.SUCCESS,
        });
    } catch (error) {
        // Handle any errors and send an error response
        console.log(error.message);
        res.status(500).send({
            message: `UNKNOWN_SERVER_ERROR: ${error.message}`,
            errorCode: errorCodes.UNKNOWN_SERVER_ERROR,
        });
    }
});

router.get('/bus-routes/:busId', async (req, res, next) => {
    try {
        const busId = req?.params.busId;
        const userId = req?.user._id;
        const user = await userModel.findOne({ _id: userId, isAdmin: true });
        if (!user) {
            res.status(401).send({
                message: "UNAUTHORIZED",
                errorCode: errorCodes.UNAUTHORIZED,
            });
            return;
        }

        if (!isValidObjectId(busId)) {
            res.status(403).send({
                errorCode: errorCodes.INVALID_BUS_ID,
                message: 'INVALID_BUS_ID',
            });
            return;
        }

        const routes = await routeModel.find({ bus: busId});
        res.status(200).send({
            message: 'bus routes',
            errorCode: errorCodes.SUCCESS,
            data: routes,
        });
    } catch (error) {
        res.status(500).send({
            message: `UNKNOWN_SERVER_ERROR: ${error.message}`,
            errorCode: errorCodes.UNKNOWN_SERVER_ERROR
        })
    }
})

router.delete('/bus-route/:routeId', async (req, res, next) => {
    try {
        const routeId = req?.params.routeId;
        const userId = req.user._id;
        const user = await userModel.findOne({ _id: userId, isAdmin: true });
        if (!user) {
            res.status(401).send({
                message: "UNAUTHORIZED",
                errorCode: errorCodes.UNAUTHORIZED,
            })
            return;
        }
        if (!routeId) {
            res.status(403).send({
                message: "REQUIRED_PARAMETER_MISSING",
                errorCode: errorCodes.REQUIRED_PARAMETER_MISSING,
            })
            return;
        }
        await routeModel.deleteOne(routeId);
        res.status(200).send({
            message: "Bus Route Deleted Successfully",
            errorCode: errorCodes.SUCCESS
        })
    } catch (error) {
        res.status(500).send({
            message: `UNKNOWN_SERVER_ERROR: ${error.message}`,
            errorCode: errorCodes.UNKNOWN_SERVER_ERROR
        })
    }
})

export default router;
